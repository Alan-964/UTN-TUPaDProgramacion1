print("Actividad N° 1")
print("Hola Mundo!")

print("")
print("Actividad N° 2")
nombre = input("Como te llamás? ")
print(f"Hola {nombre}!")

print("")
print("Actividad N° 3")
nombre = input("Ingrese su nombre: ")
apellido = input("Ingrese su apellido: ")
edad = input("Ingrese su edad: ")
resi = input("Ingrese su lugar de residencia: ")
print(f"Soy {nombre} {apellido}, tengo {edad} años y vivo en {resi}.")

print("")
print("Actividad N° 4")
radio = float(input("Ingrese el radio del círculo: "))
area = 3.1416 * radio ** 2
perimetro = 2 * 3.1416 * radio
print(f"El área del círculo es {area}.")
print(f"El perímetro del círculo es {perimetro}.")

print("")
print("Actividad N° 5")
seg = int(input("Ingrese la cantidad de segundos: "))
hora = seg / 3600
print(f"{seg} segundos equivale a {hora} horas.")

print("")
print("Actividad N° 6")
num = int(input("Ingrese un número: "))
print(f"{num} x 1 =", num * 1)
print(f"{num} x 2 =", num * 2)
print(f"{num} x 3 =", num * 3)
print(f"{num} x 4 =", num * 4)
print(f"{num} x 5 =", num * 5)
print(f"{num} x 6 =", num * 6)
print(f"{num} x 7 =", num * 7)
print(f"{num} x 8 =", num * 8)
print(f"{num} x 9 =", num * 9)
print(f"{num} x 10 =", num * 10)

print("")
print("Actividad N° 7")
num1 = int(input("Ingrese el primer número: "))
num2 = int(input("Ingrese el segundo número: "))
print(f"{num1} + {num2} = ", num1 + num2)
print(f"{num1} / {num2} = ", num1 / num2)
print(f"{num1} * {num2} = ", num1 * num2)
print(f"{num1} - {num2} = ", num1 - num2)

print("")
print("Actividad N° 8")
alt = float(input("Ingrese su altura en metros: "))
peso = float(input("Ingrese su peso en kilogramos: "))
imc = peso / (alt ** 2)
print(f"Su índice de masa corporal es {imc}.")

print("")
print("Actividad N° 9")
cel = int(input("Ingrese una temperatura en grados celsius: "))
far = (9/5 * cel) + 32
print(f"{cel}° celsius equivale a {far}° fahrenheit.")

print("")
print("Actividad N° 10")
num1 = int(input("Ingrese el primer número: "))
num2 = int(input("Ingrese el segundo número: "))
num3 = int(input("Ingrese el tercer número: "))
num4 = (num1 + num2 + num3) / 3
print(f"El promedio es de {num4}.")